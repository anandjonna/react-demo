import React from 'react';
import logo from './logo.svg';
import './App.css';
import SignIn from './components/authntication/SignIn';
import SignUp from './components/authntication/SignUp';
import Home from './components/Home';
import ContactUs from './components/ContactUs';
import {BrowserRouter as Router,Route} from 'react-router-dom';
import NavBar from './components/nav/NavBar';
import Auth from './components/authntication/Auth';
import history from './history';
import DetailsPage from './components/DetailPage';
import Confirm from './components/Confirm';

function App() {
  console.log(window.location)
  return (
    <div>
    <Router history={history}>
       <div>
       <NavBar />
       <Route exact path="/" component={Home} />
       <Route path="/contact"> <ContactUs /></Route>
       <Route path="/signin" component={SignIn} />
       <Route path="/details" component={DetailsPage} />
       <Route path="/confirm" component={Confirm} />
       {/* <Route path="/signup" component={SignUp} /> */}
     </div>
    </Router>
    </div>
  );
}

export default App;

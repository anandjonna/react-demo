import React,{Component} from 'react';
import history from '../history';



class DetailPage extends Component{

    book=()=>{
        history.push('/confirm');
        window.location.reload();
    }
    render(){
        let item = this.props.location.state.item;
        return(
            <div className="container">
                <div className="row">
                    <div className="col-md-8">
                    <h1>{item.title}</h1>
                <p>{item.body}</p>
                    </div>
                    <div className="col-md-4">
                    <div  class="card shadow m-2 bg-secondary text-white" style={{ width: '280px' }} >
                        <img class="card-img-top" src={item.img} alt="Card image" width='300' height='200' />
                        <div class="card-body text-center">
                            {/* <h4 class="card-title">{item.price}</h4> */}
                            <p class="card-text">price:{item.price}</p>
                            <button onClick={this.book} className="btn btn-lg btn-danger">Book Now</button>
                        </div>
                    </div>
                    </div>

                </div>
              
            </div>
        )
    }
   
}

export default DetailPage;
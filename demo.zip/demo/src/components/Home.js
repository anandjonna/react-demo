import React, { Component } from 'react';
import geyser1 from './img/geyser1.jpg';
import wm from './img/washing machine1.jpg';
import plumbing from './img/plumbing1.jpg';
import wp from './img/water purifier 2.jpg';
import refrigirator from './img/fridge2.jpg';
import electronics from './img/electricworks2.jpg';
import Modal from 'react-modal';
import history from '../history';
import DetailPage from './DetailPage';
import { Link } from 'react-router-dom'



const electricDetails = [
    {
        img: electronics,
        price: 199,
        name: 'Electrical Works',
        title: 'General electrical work',
        body: 'Electricity is a fairly complicated (and hazardous) subject for most people and all kinds of electrical services and maintenance works should be left in the good hands of expert electricians.',
    },
    {
        img: geyser1,
        price: 199,
        name: 'Geyser'
    },
    {
        img: wm,
        price: 299,
        name: 'Washing Machine'
    }, {
        img: wp,
        price: 199,
        name: 'Water Purifier'
    },
    {
        img: plumbing,
        price: 199,
        name: 'Plubming'
    },
    {
        img: refrigirator,
        price: 299,
        name: 'Fridge'
    }
]

class Home extends Component {
    state = {
        isModalOpen: false,
        email: '',
        pswd: ''
    }

    componentDidMount() {
        this.setState({ isModalOpen: true })
    }
    itemDetails = (item) => {
        history.push(`/details`, { item })
        window.location.reload();

    }

    render() {

        let items = electricDetails.map(item => {

            return (

                <div style={{ float: 'left' }}>
                    <div onClick={() => this.itemDetails(item)} class="card shadow m-2 bg-secondary text-white" style={{ width: '280px' }} >
                        <img class="card-img-top" src={item.img} alt="Card image" width='300' height='200' />
                        <div class="card-body">
                            {/* <h4 class="card-title">{item.price}</h4> */}
                            <p class="card-text">{item.name}</p>
                        </div>
                    </div>
                </div>
            )
        })
        return (<div className="container text-center" >
            {items}
        </div>)
    }

}

export default Home;

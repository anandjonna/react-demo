import React, { Component } from 'react';
import Modal from 'react-modal';
import {Link,withRouter} from 'react-router-dom';
import history from '../../history';

class SignIn extends Component {
  state = {
    isModalOpen: false,
    email:'',
    pswd:''
  }

  componentDidMount() {
    this.setState({ isModalOpen: true })
  }

  closeModal(){
    this.setState({ isModalOpen : false});
    history.push('/')
    window.location.reload();
  }
  onInputChange=(e)=>{
    this.setState({[e.target.name]:e.target.value})
  }
  onLogin=(e)=>{
    e.preventDefault();
    console.log(this.state.email,this.state.pswd)
    if(this.state.email="nagashamili@gmail.com" && this.state.pswd === "meradosth"){
      this.closeModal();
    }else{
      console.log("login fail")
    }
  }

  render() {
    console.log(this.state)
    return (
      <div>
        <Modal
          isOpen={this.state.isModalOpen}
          onRequestClose = {this.closeModal}
          ariaHideApp={false}
        >
          <div class="container">
            <h4 className="text-right" onClick={()=>this.closeModal()}>X</h4>
            <h2 className="text-center">Please Login</h2>
            <form onSubmit={this.onLogin}>
              <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" onChange={this.onInputChange} class="form-control" placeholder="Enter email" name="email" />
              </div>
              <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" onChange={this.onInputChange} class="form-control" placeholder="Enter password" name="pswd" />
              </div>
              <div className="text-right">
              <button type="submit" class="btn btn-primary" onClick={this.Login}>Login</button>
              </div>
            </form>
          </div>
        </Modal>

      </div>
    )
  }
}

export default withRouter(SignIn);
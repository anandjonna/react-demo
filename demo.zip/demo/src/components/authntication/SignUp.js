import React from 'react';


const SignUp = () => {
    return(
        <div>
            This is signup page.
        </div>
    )
}

export default SignUp;
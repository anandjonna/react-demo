import React, { Component } from 'react';
import Modal from 'react-modal';
import { Link, withRouter } from 'react-router-dom';
import history from '../history';

class Confirm extends Component {
    state = {
        isModalOpen: false,
    }

    componentDidMount() {
        this.setState({ isModalOpen: true })
    }

    closeModal() {
        this.setState({ isModalOpen: false });
        // history.push('/')
        // window.location.reload();
    }



    render() {
        console.log(this.state)
        return (
            <div>
                <Modal
                    isOpen={this.state.isModalOpen}
                    onRequestClose={this.closeModal}
                    ariaHideApp={false}
                >
                    <div class="container">
                        <div class="card bg-success text-white text-center">
                            <div class="card-header">Confirmed !</div>
                            <div class="card-body">Thank You for Booking</div>
                            <div class="card-footer">See You soon...</div>
                        </div>
                    </div>
                </Modal>

            </div>
        )
    }
}

export default withRouter(Confirm);
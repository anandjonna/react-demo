import React from 'react';

const ContactUs = () => {
    return(
        <div>
            This is Contact us.
        </div>
    )
}

export default ContactUs;